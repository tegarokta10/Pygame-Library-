# ============================================================
# CART.PY
# Materi: Function, Parameter, Condition, Loop, Dictionary
# ============================================================

# Mengambil data products dari products.py.
#
# IMPORT
# Import digunakan untuk menggunakan kode dari file Python lain.
#
# Ini merupakan contoh sederhana bagaimana sebuah program
# dapat dibagi menjadi beberapa file agar lebih mudah
# dikelola.

from Products import products


# ============================================================
# FUNCTION: ADD TO CART
# ============================================================

def add_to_cart(cart, product_name, quantity):

    # CONDITION
    # Kita harus mengecek apakah barang sudah ada
    # di dalam keranjang.

    if product_name in cart:

        # Jika sudah ada:
        # jumlah barang ditambahkan.

        cart[product_name] += quantity

    else:

        # Jika belum ada:
        # buat data barang baru.

        cart[product_name] = quantity


# ============================================================
# FUNCTION: CALCULATE SUBTOTAL
# ============================================================

def calculate_subtotal(cart):

    # Variable untuk menyimpan hasil perhitungan.

    subtotal = 0

    # LOOP
    # Mengulang semua barang yang ada di keranjang.

    for product_name, quantity in cart.items():

        # Mengambil harga barang dari dictionary products.

        price = products[product_name]

        # Menghitung:
        #
        # harga × jumlah
        #
        # kemudian ditambahkan ke subtotal.

        subtotal += price * quantity

    # RETURN
    # Mengirim hasil perhitungan kembali
    # kepada bagian program yang memanggil function.

    return subtotal


# ============================================================
# FUNCTION: CALCULATE DISCOUNT
# ============================================================

def calculate_discount(subtotal):

    # CONDITION
    #
    # Jika subtotal mencapai Rp20.000,
    # pelanggan mendapatkan diskon 10%.

    if subtotal >= 20000:

        return subtotal * 0.10

    # Jika kondisi tidak terpenuhi,
    # tidak ada diskon.

    return 0


# ============================================================
# KONSEP YANG BISA DIAJARKAN
# ============================================================
#
# 1. Import
# 2. Function
# 3. Parameter
# 4. Argument
# 5. Condition (if / else)
# 6. Membership operator (in)
# 7. Dictionary
# 8. For loop
# 9. Arithmetic operator
# 10. Return
#
# MINI CHALLENGE:
#
# "Bagaimana kalau diskonnya menjadi 20%?"
#
# Atau:
#
# "Bagaimana kalau diskon hanya diberikan jika
# pembelian lebih dari Rp50.000?"
#
# ============================================================