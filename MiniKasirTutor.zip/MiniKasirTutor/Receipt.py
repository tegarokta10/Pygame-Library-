# ============================================================
# RECEIPT.PY
# Materi: Function, Loop, String Formatting
# ============================================================

from Products import products


# ============================================================
# FUNCTION: PRINT RECEIPT
# ============================================================

def print_receipt(
    cart,
    subtotal,
    discount,
    total,
    payment
):

    # Menghitung kembalian.

    change = payment - total


    # ========================================================
    # HEADER STRUK
    # ========================================================

    print("\n")
    print("=" * 40)
    print("              STRUK")
    print("=" * 40)


    # ========================================================
    # MENAMPILKAN BARANG
    # ========================================================

    # LOOP
    # Mengambil semua barang yang dibeli.

    for product_name, quantity in cart.items():

        # Mengambil harga barang.

        price = products[product_name]

        # Menghitung total harga barang tersebut.

        item_total = price * quantity

        # STRING FORMATTING
        #
        # <12 berarti teks menggunakan ruang
        # selebar 12 karakter dan rata kiri.
        #
        # :,.0f digunakan untuk menampilkan angka
        # dengan pemisah ribuan tanpa desimal.

        print(
            f"{product_name:<12} "
            f"x{quantity:<3} "
            f"Rp{item_total:,.0f}"
        )


    # ========================================================
    # TOTAL PEMBAYARAN
    # ========================================================

    print("-" * 40)

    print(
        f"{'Subtotal':<20} "
        f"Rp{subtotal:,.0f}"
    )

    print(
        f"{'Diskon':<20} "
        f"Rp{discount:,.0f}"
    )

    print(
        f"{'Total':<20} "
        f"Rp{total:,.0f}"
    )

    print(
        f"{'Bayar':<20} "
        f"Rp{payment:,.0f}"
    )

    print(
        f"{'Kembalian':<20} "
        f"Rp{change:,.0f}"
    )


    # ========================================================
    # FOOTER
    # ========================================================

    print("=" * 40)
    print("          TERIMA KASIH!")
    print("=" * 40)


# ============================================================
# KONSEP YANG BISA DIAJARKAN
# ============================================================
#
# 1. Function
# 2. Parameter
# 3. For loop
# 4. Dictionary
# 5. Arithmetic
# 6. String formatting
# 7. Return value (melalui hasil perhitungan)
#
# MINI CHALLENGE:
#
# "Bagaimana cara menambahkan nama toko?"
#
# "Bagaimana cara menambahkan tanggal pembelian?"
#
# "Bagaimana cara menampilkan jumlah total barang?"
#
# ============================================================