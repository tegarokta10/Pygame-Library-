# ============================================================
# MAIN.PY
# Materi: Program Flow, While Loop, Condition, Input
# ============================================================

# IMPORT
#
# Kita mengambil function dan data dari file lain.
#
# Dengan cara ini, main.py tidak perlu mengetahui
# detail bagaimana setiap function bekerja.

from Products import products, show_products

from Cart import (
    add_to_cart,
    calculate_subtotal,
    calculate_discount
)

from Receipt import print_receipt


# ============================================================
# FUNCTION: CHOOSE PRODUCT
# ============================================================

def choose_product():

    # Menampilkan daftar produk.

    show_products()

    # INPUT
    #
    # input() digunakan untuk menerima data
    # yang diberikan oleh pengguna.
    #
    # Hasil input selalu berupa STRING.

    choice = input("\nPilih barang (1-5): ")


    # Mengambil semua nama produk dari dictionary
    # menjadi sebuah list.

    product_names = list(products.keys())


    # CONDITION
    #
    # Memeriksa apakah pilihan pengguna valid.

    if choice not in ["1", "2", "3", "4", "5"]:

        print("Pilihan tidak tersedia.")

        return None


    # Mengubah pilihan menjadi index list.
    #
    # User memilih:
    # 1 → index 0
    # 2 → index 1
    # 3 → index 2
    # 4 → index 3

    return product_names[int(choice) - 1]


# ============================================================
# FUNCTION: MAIN
# ============================================================

def main():

    # Dictionary kosong sebagai keranjang belanja.

    cart = {}


    print("=" * 40)
    print("             MINI KASIR")
    print("=" * 40)


    # ========================================================
    # PROSES PEMBELIAN
    # ========================================================

    # WHILE LOOP
    #
    # Kita tidak tahu berapa banyak barang
    # yang ingin dibeli pengguna.
    #
    # Oleh karena itu kita menggunakan while.
    #
    # Program akan terus berjalan sampai
    # pengguna memilih untuk berhenti.

    while True:

        product_name = choose_product()


        # Jika pilihan tidak valid,
        # kembali ke awal loop.

        if product_name is None:
            continue


        # Meminta jumlah barang.

        quantity = int(
            input("Jumlah: ")
        )


        # Memasukkan barang ke keranjang.

        add_to_cart(
            cart,
            product_name,
            quantity
        )


        print(
            f"{product_name} x{quantity} "
            "berhasil ditambahkan!"
        )


        # Menanyakan apakah user ingin membeli
        # barang lainnya.

        again = input(
            "\nTambah barang lagi? (y/n): "
        )


        # CONDITION
        #
        # Jika user tidak memilih "y",
        # maka proses pembelian selesai.

        if again.lower() != "y":
            break


    # ========================================================
    # CHECKOUT
    # ========================================================

    # Mengecek apakah keranjang kosong.

    if not cart:

        print("Keranjang kosong.")

        return


    # Menghitung subtotal.

    subtotal = calculate_subtotal(cart)


    # Menghitung diskon.

    discount = calculate_discount(subtotal)


    # Menghitung total akhir.

    total = subtotal - discount


    print("\n================================")
    print(f"Total pembayaran: Rp{total:,.0f}")
    print("================================")


    # ========================================================
    # PEMBAYARAN
    # ========================================================

    # Kita menggunakan while karena uang yang
    # dimasukkan bisa saja belum cukup.

    while True:

        payment = int(
            input("Masukkan uang pembayaran: ")
        )


        # CONDITION
        #
        # Jika uang cukup, keluar dari loop.

        if payment >= total:
            break


        # Jika uang kurang,
        # minta pengguna memasukkan kembali.

        print("Uang tidak cukup.")


    # ========================================================
    # CETAK STRUK
    # ========================================================

    print_receipt(
        cart,
        subtotal,
        discount,
        total,
        payment
    )


# ============================================================
# PROGRAM START
# ============================================================

# Baris ini memastikan main() hanya dijalankan
# ketika file main.py dijalankan secara langsung.
#
# Ini juga merupakan konsep Python yang bagus
# untuk dikenalkan ketika membahas struktur program.

if __name__ == "__main__":
    main()


# ============================================================
# KONSEP YANG BISA DIAJARKAN
# ============================================================
#
# 1. Import
# 2. Function
# 3. Input
# 4. Variable
# 5. List
# 6. Dictionary
# 7. While loop
# 8. For loop (melalui function lain)
# 9. Condition
# 10. break
# 11. continue
# 12. return
# 13. Program flow
# 14. Modular programming
#
# MINI CHALLENGE:
#
# "Bagaimana kalau kita ingin menambahkan menu
# untuk menghapus barang dari keranjang?"
#
# ============================================================