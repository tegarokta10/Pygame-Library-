# ============================================================
# PRODUCTS.PY
# Materi: Dictionary, Function, Loop
# ============================================================

# DICTIONARY
# Dictionary digunakan untuk menyimpan data dalam bentuk
# pasangan KEY dan VALUE.
#
# KEY   = nama barang
# VALUE = harga barang
#
# Contoh:
# "Pensil" -> 3000
#
# Pertanyaan untuk siswa:
# "Kenapa kita menggunakan dictionary, bukan hanya list?"

products = {
    "Pensil": 3000,
    "Buku": 10000,
    "Penghapus": 2000,
    "Penggaris": 5000,
    "Pentol" : 5000
}


# FUNCTION
# Function adalah blok kode yang memiliki tugas tertentu.
#
# Keuntungan menggunakan function:
# - Kode lebih terorganisir
# - Bisa digunakan kembali
# - Lebih mudah dirawat
#
# Pertanyaan untuk siswa:
# "Apa yang terjadi kalau daftar barang ingin ditampilkan
# di beberapa tempat dalam program?"

def show_products():

    print("\n=== DAFTAR BARANG ===")

    # LOOP
    # for digunakan untuk mengulang setiap data.
    #
    # .items() mengambil KEY dan VALUE dari dictionary.
    #
    # name  = nama barang
    # price = harga barang

    for number, (name, price) in enumerate(
        products.items(),
        start=1
    ):
        print(f"{number}. {name} - Rp{price:,}")


# ============================================================
# KONSEP YANG BISA DIAJARKAN
# ============================================================
#
# 1. Dictionary
# 2. Key dan Value
# 3. Function
# 4. Parameter dan argument
# 5. For loop
# 6. enumerate()
# 7. String formatting
#
# MINI CHALLENGE:
# "Tambahkan produk baru ke dictionary."
#
# Contoh:
# "Spidol": 7000
#
# ============================================================