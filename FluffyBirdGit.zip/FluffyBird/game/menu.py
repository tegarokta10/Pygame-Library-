"""
game/menu.py - Stage 3: state MENU.

PYGAME EQUIVALENT dari CodeSceneMenuCreate.js (Phaser). State dibuat sebagai
class sederhana dengan method:
    enter()            -> dipanggil sekali saat masuk state (padanan create())
    handle_event(ev)    -> padanan event listener Phaser (pointerup, gameobjectover, dst.)
    update(dt)           -> update animasi sederhana (padanan tween)
    draw(surface)          -> render

save_highscore()/load_highscore() juga dipakai oleh game/play.py saat game
over, sehingga logic baca-tulis highscore terpusat di satu tempat (tidak ada
lagi mismatch key "highscore" vs "Highscore" seperti di source asli).
"""

import json
import os
import pygame
import config


def load_highscore():
    if not os.path.exists(config.SAVE_FILE):
        return 0
    try:
        with open(config.SAVE_FILE, "r") as f:
            data = json.load(f)
        return data.get(config.HIGHSCORE_KEY, 0)
    except (json.JSONDecodeError, OSError):
        return 0


def save_highscore(score):
    data = {config.HIGHSCORE_KEY: score}
    try:
        with open(config.SAVE_FILE, "w") as f:
            json.dump(data, f)
    except OSError as e:
        print(f"[menu] WARNING: gagal menyimpan {config.SAVE_FILE}: {e}")


class MenuState:
    def __init__(self, assets):
        self.assets = assets
        self.font_title = pygame.font.SysFont(None, 64)
        self.font_score = pygame.font.SysFont(None, 30)
        self.next_state = None

        self.btn_play_scale = 0.50  # ukuran tombol play sedikit lebih kecil dari ukuran asli
        self.btn_play_rect = None
        self.btn_hover = False
        self.btn_scale_t = 0.0     # animasi scale tombol play (0 -> 1)

        self.title_start_y = 200.0 - 384.0
        self.title_y = self.title_start_y
        self.title_anim_t = 0.0
        self.title_scale_t = 0.0

        self.highscore = 0

    def enter(self):
        self.next_state = None
        self.btn_scale_t = 0.0
        self.title_anim_t = 0.0
        self.title_scale_t = 0.0
        self.title_y = self.title_start_y
        self.highscore = load_highscore()

        snd_ambience = self.assets.sounds.get("snd_ambience")
        if snd_ambience is not None:
            snd_ambience.set_volume(0.35)
            snd_ambience.play(loops=-1)

        img_play = self.assets.images.get("btn_play")
        if img_play is not None:
            w, h = img_play.get_size()
            self.btn_play_rect = pygame.Rect(0, 0, int(w * self.btn_play_scale), int(h * self.btn_play_scale))
            self.btn_play_rect.center = (config.GAME_WIDTH // 2, config.GAME_HEIGHT // 2 + 75)
        else:
            # fallback: tetap sediakan area klik meski gambar tombol belum ada
            self.btn_play_rect = pygame.Rect(0, 0, int(200 * self.btn_play_scale), int(80 * self.btn_play_scale))
            self.btn_play_rect.center = (config.GAME_WIDTH // 2, config.GAME_HEIGHT // 2 + 75)

    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.btn_hover = bool(self.btn_play_rect and self.btn_play_rect.collidepoint(event.pos))
        elif event.type == pygame.MOUSEBUTTONUP:
            if self.btn_play_rect and self.btn_play_rect.collidepoint(event.pos):
                self._play_button_action()

    def _play_button_action(self):
        # CATATAN (dari source asli): urutan "pindah scene dulu, baru mainkan
        # sound" dipertahankan persis; efek suara berpotensi terpotong karena
        # state langsung berganti setelahnya (sesuai catatan bug source asli).
        self.next_state = "play"
        snd_touch = self.assets.sounds.get("snd_touch")
        if snd_touch is not None:
            snd_touch.play()

        snd_ambience = self.assets.sounds.get("snd_ambience")
        if snd_ambience is not None:
            snd_ambience.stop()

    def update(self, dt):
        if self.btn_scale_t < 1.0:
            self.btn_scale_t = min(self.btn_scale_t + dt / 0.5, 1.0)   # duration 500ms

        if self.title_anim_t < 1.0:
            self.title_anim_t = min(self.title_anim_t + dt / 0.75, 1.0)   # duration 750ms
            self.title_y = self.title_start_y + (200.0 - self.title_start_y) * self.title_anim_t

        if self.title_scale_t < 1.0:
            self.title_scale_t = min(self.title_scale_t + dt / 0.75, 1.0)

    def draw(self, surface):
        bg = self.assets.images.get("bg_start")
        if bg is not None:
            rect = bg.get_rect(center=(config.GAME_WIDTH // 2, config.GAME_HEIGHT // 2))
            surface.blit(bg, rect)
        else:
            surface.fill((135, 206, 235))

        # ---- Title / fallback ----
        title_img = self.assets.images.get("title_game")
        if title_img is not None:
            scale = self.title_scale_t
            if scale > 0:
                w = max(int(title_img.get_width() * scale), 1)
                h = max(int(title_img.get_height() * scale), 1)
                img = pygame.transform.smoothscale(title_img, (w, h))
                rect = img.get_rect(center=(config.GAME_WIDTH // 2, int(self.title_y)))
                surface.blit(img, rect)
        else:
            # TODO: NEED USER CONFIRMATION - asset title_game belum tersedia,
            # fallback pakai teks sederhana.
            text = self.font_title.render("", True, (255, 115, 46))
            rect = text.get_rect(center=(config.GAME_WIDTH // 2, int(self.title_y)))
            surface.blit(text, rect)

        # ---- Play button ----
        img_play = self.assets.images.get("btn_play")
        if img_play is not None and self.btn_play_rect is not None:
            scale = self.btn_scale_t * self.btn_play_scale
            if scale > 0:
                w = max(int(img_play.get_width() * scale), 1)
                h = max(int(img_play.get_height() * scale), 1)
                img = pygame.transform.smoothscale(img_play, (w, h))
                if self.btn_hover:
                    img = img.copy()
                    img.fill((97, 97, 97, 255), special_flags=pygame.BLEND_RGBA_MULT)
                rect = img.get_rect(center=self.btn_play_rect.center)
                surface.blit(img, rect)
        elif self.btn_play_rect is not None:
            color = (97, 97, 97) if self.btn_hover else (255, 165, 0)
            pygame.draw.rect(surface, color, self.btn_play_rect, border_radius=8)
            text = self.font_score.render("PLAY", True, (255, 255, 255))
            surface.blit(text, text.get_rect(center=self.btn_play_rect.center))

        # ---- Highscore panel ----
        panel = self.assets.images.get("panel_skor")
        panel_center = (config.GAME_WIDTH // 2, config.GAME_HEIGHT - 120)
        if panel is not None:
            panel_alpha = panel.copy()
            panel_alpha.set_alpha(int(0.8 * 255))
            rect = panel_alpha.get_rect(center=panel_center)
            surface.blit(panel_alpha, rect)
            text_x = rect.centerx + 25
        else:
            text_x = panel_center[0] + 25

        text = self.font_score.render(f"Highscore: {self.highscore}", True, (255, 115, 46))
        surface.blit(text, text.get_rect(center=(text_x, panel_center[1])))
