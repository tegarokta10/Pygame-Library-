"""
game/__init__.py - Stage 2: Asset Loading (terpusat).

Sengaja diletakkan di __init__.py (bukan file baru) supaya struktur project
tetap sesuai spesifikasi (main.py, config.py, game/menu.py, game/play.py,
game/player.py, game/obstacle.py) tanpa menambah file/folder baru.
"""

import os
import pygame
import config


class Assets:
    """Wadah sederhana untuk semua image & sound yang sudah dimuat."""

    def __init__(self):
        self.images = {}
        self.sounds = {}

    def load(self):
        self._load_images()
        self._load_sounds()

    def _load_images(self):
        for key, filename in config.IMAGE_ASSETS.items():
            path = os.path.join(config.IMAGES_DIR, filename)
            if not os.path.exists(path):
                print(f"[Assets] WARNING: image asset tidak ditemukan untuk key '{key}': {path}")
                self.images[key] = None
                continue
            try:
                self.images[key] = pygame.image.load(path).convert_alpha()
            except pygame.error as e:
                print(f"[Assets] ERROR memuat image '{key}' dari {path}: {e}")
                self.images[key] = None

        # title_game: tidak ada asset asli -> fallback text (lihat menu.py)
        # TODO: NEED USER CONFIRMATION
        self.images.setdefault("title_game", None)

    def _load_sounds(self):
        if not pygame.mixer.get_init():
            print("[Assets] WARNING: mixer belum diinisialisasi, semua sound di-skip")
            for key in config.SOUND_ASSETS:
                self.sounds[key] = None
            self.sounds["snd_touch"] = None
            self.sounds["snd_transisi_menu"] = None
            return

        for key, filename in config.SOUND_ASSETS.items():
            path = os.path.join(config.SOUNDS_DIR, filename)
            if not os.path.exists(path):
                print(f"[Assets] WARNING: sound asset tidak ditemukan untuk key '{key}': {path}")
                self.sounds[key] = None
                continue
            try:
                self.sounds[key] = pygame.mixer.Sound(path)
            except pygame.error as e:
                print(f"[Assets] ERROR memuat sound '{key}' dari {path}: {e}")
                self.sounds[key] = None

        # snd_touch (klik tombol Play di menu) memakai file yang sama dengan
        # snd_klik_* sesuai mapping asset yang diberikan.
        touch_path = os.path.join(config.SOUNDS_DIR, "klik_bird.mp3")
        if os.path.exists(touch_path):
            try:
                self.sounds["snd_touch"] = pygame.mixer.Sound(touch_path)
            except pygame.error as e:
                print(f"[Assets] ERROR memuat sound 'snd_touch' dari {touch_path}: {e}")
                self.sounds["snd_touch"] = None
        else:
            print(f"[Assets] WARNING: sound asset tidak ditemukan untuk key 'snd_touch': {touch_path}")
            self.sounds["snd_touch"] = None

        # snd_transisi_menu: SAFELY SKIPPED
        # TODO: NEED USER CONFIRMATION
        # Original Phaser source references snd_transisi_menu,
        # but no matching asset is available.
        self.sounds["snd_transisi_menu"] = None
