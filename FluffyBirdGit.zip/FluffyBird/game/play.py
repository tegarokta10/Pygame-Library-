"""
game/play.py - Stage 4-9: state PLAY.

PYGAME EQUIVALENT dari CodeScenePlayCreate.js + CodeScenePlayUpdate.js.
Urutan update loop dipertahankan PERSIS seperti source asli:

    update_player -> update_background -> spawn_obstacle -> update_obstacles
    -> update_score -> check_collision -> check_player_bounds
"""

import random
import pygame
import config
from .player import Player
from .obstacle import Obstacle
from .menu import save_highscore, load_highscore


class PlayState:
    def __init__(self, assets):
        self.assets = assets
        self.font_score = pygame.font.SysFont(None, config.SCORE_FONT_SIZE)
        self.next_state = None

        # atribut yang dipakai draw()/update() sebelum enter() pertama kali
        self.score = 0
        self.obstacles = []
        self.backgrounds = []
        self.player = None
        self.is_game_running = False
        self.dying = False

    def enter(self):
        self.next_state = None
        self.score = 0
        self.is_game_running = False
        self.dying = False
        self.death_elapsed = 0.0
        # fallback fade sederhana (Stage 10/tween penuh belum diimplementasikan)
        self.death_duration = 1.0

        # BUG FIX (dari source asli): source punya dua nama beda
        # (this.timeHalangan diinisialisasi di create(), this.timerHalangan
        # yang dipakai di update()) sehingga timer efektif tidak pernah
        # di-set ke 0 di awal secara sengaja. Di port ini SENGAJA diperbaiki
        # dengan satu nama konsisten: obstacle_timer, mulai dari 0 sehingga
        # obstacle pertama langsung spawn pada frame pertama.
        self.obstacle_timer = 0

        self.obstacles = []
        self.player = Player(self.assets.images.get("chara"))

        # ---- Background: segmen loop dibuat berurutan agar tidak ada jarak kosong ----
        self.backgrounds = []
        bg_img_back = self.assets.images.get("fg_loop_back")
        fg_img = self.assets.images.get("fg_loop")
        back_w = bg_img_back.get_width() if bg_img_back is not None else config.BG_LOOP_WIDTH
        fg_w = fg_img.get_width() if fg_img is not None else config.BG_LOOP_WIDTH
        seg_width = max(back_w, fg_w)

        # posisi x disimpan sebagai center-x (untuk penggunaan get_rect(center=...))
        for i in range(config.BG_LAYER_COUNT):
            seg_x = seg_width / 2 + (i * seg_width)
            self.backgrounds.append({
                "bg": {"image": bg_img_back, "x": seg_x,
                       "y": config.GAME_HEIGHT * 0.52, "speed": config.BG_SPEED},
                "fg": {"image": fg_img, "x": seg_x,
                       "y": config.GAME_HEIGHT - 30, "speed": config.FG_SPEED},
            })

        # ---- Audio: hentikan musik menu, mainkan musik gameplay ----
        snd_ambience = self.assets.sounds.get("snd_ambience")
        if snd_ambience is not None:
            snd_ambience.stop()
        game_music = self.assets.sounds.get("snd_game_music")
        if game_music is not None:
            game_music.set_volume(0.35)
            game_music.play(loops=-1)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONUP:
            if not self.is_game_running:
                return
            snd_click_list = [
                self.assets.sounds.get("snd_klik_1"),
                self.assets.sounds.get("snd_klik_2"),
                self.assets.sounds.get("snd_klik_3"),
            ]
            # CATATAN (dari source asli): formula random Phaser
            # (Math.floor(Math.random()*2)) hanya pernah menghasilkan index
            # 0 atau 1, index 2 (snd_klik_3) TIDAK PERNAH terpilih. Behavior
            # ini dipertahankan persis di sini (bukan diperbaiki diam-diam).
            idx = random.randint(0, 1)
            snd = snd_click_list[idx]
            if snd is not None:
                snd.play()
            self.player.start_flap()

    def update(self, dt):
        self.player.update(dt)

        # game mulai berjalan begitu animasi spawn player selesai
        # (padanan onComplete tween kedua di initializePlayer(), yang
        # men-set isGameRunning = true)
        if not self.is_game_running and self.player.spawn_done and not self.dying:
            self.is_game_running = True

        if self.dying:
            self._update_death(dt)
            return

        if not self.is_game_running:
            return

        self._update_background(dt)
        self._spawn_obstacle(dt)
        self._update_obstacles(dt)
        self._update_score()
        self._check_collision()
        self._check_player_bounds()

    def _update_background(self, dt):
        for layer in self.backgrounds:
            for part in (layer["bg"], layer["fg"]):
                speed_per_second = part["speed"] * config.FPS
                part["x"] -= speed_per_second * dt

                # gunakan lebar asset nyata agar wrap reliable
                width = part["image"].get_width() if part["image"] is not None else config.BG_LOOP_WIDTH

                # part["x"] disimpan sebagai center-x; jika center sudah melewati
                # separuh lebar ke kiri, pindahkan ke kanan ujung (jumlah segmen = BG_LAYER_COUNT)
                if part["x"] <= -(width / 2):
                    part["x"] += width * config.BG_LAYER_COUNT

    def _spawn_obstacle(self, dt):
        if self.obstacle_timer <= 0:
            img = self.assets.images.get("obste")
            if img is not None:
                pair_id = len(self.obstacles) if self.obstacles else 0
                pair_speed = random.randint(
                    config.OBSTACLE_SPEED_MIN,
                    config.OBSTACLE_SPEED_MIN + config.OBSTACLE_SPEED_RANDOM_RANGE,
                )
                gap = config.OBSTACLE_PAIR_GAP
                pillar_h = img.get_height()
                top_y = random.randint(30, 180) - pillar_h + 20
                bottom_y = top_y + gap + pillar_h

                self.obstacles.append(
                    Obstacle(img, x=config.OBSTACLE_SPAWN_X, y=top_y, speed=pair_speed, pair_id=pair_id, scale=1.0)
                )
                self.obstacles.append(
                    Obstacle(img, x=config.OBSTACLE_SPAWN_X, y=bottom_y, speed=pair_speed, pair_id=pair_id, scale=1.0)
                )
            self.obstacle_timer = config.OBSTACLE_TIMER_MIN
        self.obstacle_timer -= max(1, round(dt * config.FPS))

    def _update_obstacles(self, dt):
        for obstacle in self.obstacles:
            obstacle.update(dt)
        self.obstacles = [o for o in self.obstacles if not o.is_off_screen()]

    def _update_score(self):
        scored_pairs = set()
        for obstacle in self.obstacles:
            if obstacle.pair_id is None or obstacle.pair_id in scored_pairs:
                continue
            if obstacle.active and self.player.x > obstacle.x + config.OBSTACLE_PASS_OFFSET:
                scored_pairs.add(obstacle.pair_id)
                self.score += 1
                obstacle.active = False

    def _check_collision(self):
        for obstacle in self.obstacles:
            if self.player.hitbox.colliderect(obstacle.hitbox):
                obstacle.active = False
                self._trigger_player_death()
                break

    def _check_player_bounds(self):
        if self.player.is_out_of_top_bounds():
            self._trigger_player_death()

    def _trigger_player_death(self):
        if self.dying:
            return
        self.is_game_running = False
        self.dying = True
        self.death_elapsed = 0.0

        snd_dead = self.assets.sounds.get("snd_dead")
        if snd_dead is not None:
            snd_dead.play()

        game_music = self.assets.sounds.get("snd_game_music")
        if game_music is not None:
            game_music.stop()

        # CATATAN: this.trail dari source asli SENGAJA TIDAK DI-PORT.
        # this.trail tidak pernah dibuat di source asli (dead/undefined
        # reference yang berpotensi error runtime di Phaser) -> keputusan
        # project: JANGAN membuat fitur trail, dependency ini dihilangkan.

    def _update_death(self, dt):
        self.death_elapsed += dt
        t = min(self.death_elapsed / self.death_duration, 1.0)
        self.player.alpha = int(255 * (1 - t))
        if t >= 1.0:
            self._game_over()

    def _game_over(self):
        highscore = load_highscore()
        if self.score > highscore:
            save_highscore(self.score)
        self.next_state = "menu"

    def draw(self, surface):
        surface.fill((30, 30, 30))

        for layer in self.backgrounds:
            bg = layer["bg"]
            if bg["image"] is not None:
                rect = bg["image"].get_rect(midtop=(int(bg["x"]), 0))
                surface.blit(bg["image"], rect)
        for layer in self.backgrounds:
            fg = layer["fg"]
            if fg["image"] is not None:
                rect = fg["image"].get_rect(midbottom=(int(fg["x"]), config.GAME_HEIGHT))
                surface.blit(fg["image"], rect)

        if self.player is not None:
            self.player.draw(surface)

        for obstacle in self.obstacles:
            obstacle.draw(surface)

        panel = self.assets.images.get("panel_skor")
        panel_center = (config.GAME_WIDTH // 2, 60)
        if panel is not None:
            panel_alpha = panel.copy()
            panel_alpha.set_alpha(int(0.8 * 255))
            rect = panel_alpha.get_rect(center=panel_center)
            surface.blit(panel_alpha, rect)
            text_x = rect.centerx + 25
        else:
            text_x = panel_center[0] + 25

        text = self.font_score.render(str(self.score), True, (255, 115, 46))
        surface.blit(text, text.get_rect(center=(text_x, panel_center[1])))
