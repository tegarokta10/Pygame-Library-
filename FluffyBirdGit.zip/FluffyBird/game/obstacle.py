"""
game/obstacle.py - Stage 6: entity Obstacle (halangan).

PORTING NOTES:
- Origin Phaser di-set eksplisit ke (0, 0) via setOrigin(0, 0) di source asli,
  jadi (x, y) di sini adalah titik KIRI-ATAS gambar, sama seperti source.
- Collision di play.py memakai rect.collidepoint(obstacle.x, obstacle.y)
  (titik kiri-atas obstacle) SESUAI PERSIS source asli:
      this.chara.getBounds().contains(this.halangan[i].x, this.halangan[i].y)
  JANGAN diganti ke colliderect/AABB penuh, karena akan mengubah area
  collision dan behavior gameplay dibanding source.
"""

import random
import pygame
import config


class Obstacle:
    def __init__(self, image, x=None, y=None, speed=None, pair_id=None, scale=1.0):
        self.image = image
        self.x = float(x if x is not None else config.OBSTACLE_SPAWN_X)
        self.y = float(
            y if y is not None else
            random.randint(0, config.OBSTACLE_Y_RANDOM_RANGE) + config.OBSTACLE_Y_MIN
        )
        self.scale = float(scale)
        self.speed = (
            speed if speed is not None else
            random.randint(0, config.OBSTACLE_SPEED_RANDOM_RANGE) + config.OBSTACLE_SPEED_MIN
        )
        self.active = True  # padanan status_aktif: sudah dihitung skor atau belum
        self.pair_id = pair_id
        self._update_hitbox()

    def _update_hitbox(self):
        w = self.image.get_width() * self.scale if self.image is not None else 1
        h = self.image.get_height() * self.scale if self.image is not None else 1
        self.rect = pygame.Rect(int(self.x), int(self.y), max(int(w), 1), max(int(h), 1))
        self.hitbox = pygame.Rect(
            int(self.x) + max(int(w * 0.10), 1),
            int(self.y) + max(int(h * 0.10), 1),
            max(int(w * 0.80), 1),
            max(int(h * 0.80), 1),
        )

    def update(self, dt):
        speed_per_second = self.speed * config.FPS
        self.x -= speed_per_second * dt
        self._update_hitbox()

    def is_off_screen(self):
        return self.x < config.OBSTACLE_DESTROY_X

    def draw(self, surface):
        if self.image is not None:
            surface.blit(self.image, (int(self.x), int(self.y)))
