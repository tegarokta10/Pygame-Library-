"""
game/player.py - Stage 5: entity Player.

PORTING NOTES:
- Origin Phaser default untuk this.chara adalah CENTER (0.5, 0.5) karena
  tidak pernah dipanggil setOrigin() di CodeScenePlayCreate.js. Maka di sini
  (x, y) merepresentasikan titik TENGAH gambar, sama seperti source asli.
- Flap & animasi spawn memakai easing sederhana (bukan tween engine Phaser
  penuh). Ini "implementation difference" untuk Stage 5-8; animasi tween
  lengkap menyusul di Stage 10 (belum diimplementasikan, sesuai instruksi).
"""

import pygame
import config


def _ease_out_power1(t):
    # padanan sederhana untuk ease 'Power1' Phaser (ease-out kuadratik)
    return 1 - (1 - t) * (1 - t)


def _ease_out_back(t, overshoot=1.70158):
    # padanan sederhana untuk ease 'Back.Out' Phaser
    t -= 1
    return t * t * ((overshoot + 1) * t + overshoot) + 1


class Player:
    def __init__(self, image):
        self.image_orig = image
        self.x = float(config.PLAYER_START_X)
        self.y = float(config.PLAYER_START_Y)
        self.alpha = 255
        self.base_scale = config.PLAYER_SCALE
        self.scale = 0.0  # animasi spawn: scale 0 -> base_scale (padanan tween Back.Out)

        self.spawn_elapsed = 0.0
        self.spawn_delay = config.PLAYER_SPAWN_ANIM_DELAY / 1000.0
        self.spawn_duration = config.PLAYER_SPAWN_ANIM_DURATION / 1000.0
        self.spawn_done = False

        # flap state (padanan tween 'Power1' saat pointerup)
        self.flapping = False
        self.flap_start_y = self.y
        self.flap_target_y = self.y
        self.flap_elapsed = 0.0
        self.flap_duration = config.PLAYER_FLAP_DURATION / 1000.0

        self._update_rect()

    def _update_rect(self):
        w = self.image_orig.get_width() * self.scale if self.image_orig else 1
        h = self.image_orig.get_height() * self.scale if self.image_orig else 1
        self.rect = pygame.Rect(0, 0, max(int(w), 1), max(int(h), 1))
        self.rect.center = (int(self.x), int(self.y))

        # Hitbox mengikuti scale sprite saat ini, bukan angka tetap.
        # Ukuran ini dihitung dari dimensi sprite yang sedang dipakai.
        hit_w = max(int(w * 0.72), 1)
        hit_h = max(int(h * 0.72), 1)
        self.hitbox = pygame.Rect(0, 0, hit_w, hit_h)
        self.hitbox.center = self.rect.center

    def start_flap(self):
        self.flapping = True
        self.flap_elapsed = 0.0
        self.flap_start_y = self.y
        # flap yang benar adalah bergerak ke atas, bukan turun.
        self.flap_target_y = self.y - config.PLAYER_FLAP_DISTANCE

    def update(self, dt):
        # ---- Animasi spawn (scale 0 -> 1) ----
        if not self.spawn_done:
            if self.spawn_elapsed < self.spawn_delay:
                self.spawn_elapsed += dt
            else:
                progress_time = self.spawn_elapsed - self.spawn_delay
                t = min(progress_time / self.spawn_duration, 1.0) if self.spawn_duration > 0 else 1.0
                self.scale = max(0.0, min(_ease_out_back(t) * self.base_scale, self.base_scale))
                self.spawn_elapsed += dt
                if t >= 1.0:
                    self.scale = self.base_scale
                    self.spawn_done = True

        # ---- Gravitasi: burung jatuh ke bawah secara natural ----
        move_per_second = config.PLAYER_MOVE_SPEED * config.FPS
        self.y += move_per_second * dt

        # ---- Flap (tween naik saat klik) ----
        if self.flapping:
            self.flap_elapsed += dt
            t = min(self.flap_elapsed / self.flap_duration, 1.0)
            eased_t = _ease_out_power1(t)
            self.y = self.flap_start_y + (self.flap_target_y - self.flap_start_y) * eased_t
            if t >= 1.0:
                self.flapping = False

        # ---- Batas bawah player ----
        if self.y > config.PLAYER_BOTTOM_LIMIT:
            self.y = config.PLAYER_BOTTOM_LIMIT

        self._update_rect()

    def is_out_of_top_bounds(self):
        return self.y < config.PLAYER_TOP_LIMIT

    def draw(self, surface):
        if self.image_orig is None or self.scale <= 0:
            return
        w = max(int(self.image_orig.get_width() * self.scale), 1)
        h = max(int(self.image_orig.get_height() * self.scale), 1)
        img = pygame.transform.smoothscale(self.image_orig, (w, h))
        if self.alpha < 255:
            img = img.copy()
            img.set_alpha(max(self.alpha, 0))
        rect = img.get_rect(center=(int(self.x), int(self.y)))
        surface.blit(img, rect)
