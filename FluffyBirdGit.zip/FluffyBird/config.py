"""
config.py - konstanta global untuk Flappy Bird Pygame port.

CATATAN PORTING:
Nilai di bawah mengikuti CodeGlobalVariabel.js (source asli Phaser/JS).
Nilai gerak disimpan sebagai konstanta "per frame" (asumsi 60 FPS), lalu
dikonversi ke per-detik saat dipakai di game/*.py:

    per_second = per_frame * FPS
    posisi += per_second * dt

sehingga feel gameplay tetap ~sama seperti source Phaser pada 60 FPS, tapi
frame-rate independent (memakai delta time).
"""

import os

# ---- Path & Window ----
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
IMAGES_DIR = os.path.join(BASE_DIR, "assets", "images")
SOUNDS_DIR = os.path.join(BASE_DIR, "assets", "sounds")
SAVE_FILE = os.path.join(BASE_DIR, "save.json")

GAME_WIDTH = 1024
GAME_HEIGHT = 768
FPS = 60

# CATATAN (dari source asli): background/foreground di scene Play memakai
# lebar loop 1366, BUKAN GAME_WIDTH (1024). Inkonsistensi ukuran pada source
# asli dipertahankan apa adanya.
BG_LOOP_WIDTH = 1024

# ---- Player (chara) ----
PLAYER_START_X = 130
PLAYER_START_Y = GAME_HEIGHT / 2          # 384
PLAYER_MOVE_SPEED = 3                     # px/frame @60fps -> 300 px/detik
PLAYER_SCALE = 0.3                       # ukuran sprite di layar, lebih proporsional
PLAYER_BOTTOM_LIMIT = 690
PLAYER_TOP_LIMIT = -50
PLAYER_FLAP_DISTANCE = 200                # px turun saat klik
PLAYER_FLAP_DURATION = 750                # ms, durasi tween turun saat klik
PLAYER_SPAWN_ANIM_DELAY = 250             # ms, delay animasi player muncul
PLAYER_SPAWN_ANIM_DURATION = 500          # ms, durasi animasi player muncul

# ---- Background / Foreground ----
BG_LAYER_COUNT = 5                         # cukup 2 segmen agar looping tidak terlalu cepat habis
BG_SPEED = 1                              # layer belakang lebih halus
FG_SPEED = 3                              # layer depan terlihat lebih sering tapi tidak terlalu cepat hilang

# ---- Obstacle ----
OBSTACLE_SPAWN_X = 1200
OBSTACLE_Y_MIN = 60
OBSTACLE_Y_RANDOM_RANGE = 680             # y acak -> 60..739 (lihat catatan source asli)
OBSTACLE_SPEED_MIN = 4
OBSTACLE_SPEED_RANDOM_RANGE = 3           # speed stabil, agar pair bergerak konsisten
OBSTACLE_TIMER_MIN = 300                  # 5 detik per pasangan tiang (300 frame @60fps)
OBSTACLE_TIMER_RANDOM_RANGE = 0           # tidak spam, spawn 1 pasangan tiap 5 detik
OBSTACLE_PAIR_GAP = 400                   # celah di antara dua tiang agar burung bisa lewat
OBSTACLE_DESTROY_X = -200
OBSTACLE_PASS_OFFSET = 50

# ---- Score / Highscore ----
# BUG FIX (dari source asli): source Phaser memakai 2 key localStorage
# berbeda (simpan ke "highscore", baca dari "Highscore") sehingga highscore
# di menu tidak pernah ter-update dari hasil bermain. Di port ini SENGAJA
# diperbaiki -> satu key konsisten untuk baca & tulis, disimpan di save.json.
HIGHSCORE_KEY = "highscore"

# Ukuran font untuk menampilkan score di scene Play (ubah sesuai keinginan)
SCORE_FONT_SIZE = 64

# ---- Asset Map: Images ----
IMAGE_ASSETS = {
    "chara": "Chara.png",
    "bg_start": "bg_start.png",
    "fg_loop": "Loop_depan.png",
    "fg_loop_back": "Loop_belakang.png",
    "btn_play": "Play_Button.png",
    "btn_restart": "Restart_Button.png",   # belum dipakai di 4 script asli, tetap dimuat
    "panel_skor": "Skor_Panel.png",
    # [ASSET MAPPING PERLU DIKONFIRMASI]: source hanya memakai 1 key 'obste'
    # padahal tersedia 2 file (tiang_1 & tiang_2). Default ke tiang_1 sesuai
    # instruksi. Ganti baris di bawah ke "Obstacle_tiang_2.png" jika hasil
    # visual menunjukkan varian itu yang benar.
    "obste": "Obstacle_tiang_1.png",
}
# title_game: tidak ada asset asli -> fallback text di menu.py
# TODO: NEED USER CONFIRMATION - asset title_game belum tersedia

# ---- Asset Map: Sounds ----
SOUND_ASSETS = {
    "snd_dead": "Die.mp3",
    "snd_klik_1": "klik_bird.mp3",
    "snd_klik_2": "klik_bird.mp3",
    "snd_klik_3": "klik_bird.mp3",
    "snd_ambience": "Music_bg_awal.mp3",   # musik menu
    "snd_game_music": "Music_bg1.mp3",     # musik gameplay
    # CATATAN: source Phaser asli TIDAK memutar musik apa pun di scene Play
    # (Music bg1.mp3 tidak dipakai sama sekali di 4 script asli). Pemetaan
    # snd_game_music -> Music_bg1.mp3 di bawah ini adalah INTENTIONAL
    # IMPROVEMENT sesuai instruksi Stage 9, BUKAN reproduksi behavior asli.
}
# snd_transisi_menu: SAFELY SKIPPED
# TODO: NEED USER CONFIRMATION
# Original Phaser source references snd_transisi_menu,
# but no matching asset is available.
