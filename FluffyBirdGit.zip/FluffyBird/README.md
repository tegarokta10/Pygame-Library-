# Flappy Bird — Pygame Port

Porting bertahap dari Flappy Bird (JavaScript + Phaser) ke Python + Pygame.
Behavior asli dipakai sebagai referensi utama; setiap bug/inkonsistensi dari
source asli ditandai eksplisit — beberapa SENGAJA diperbaiki sesuai
keputusan project (lihat bagian "Bug dari source asli" di bawah), sisanya
dipertahankan apa adanya dan ditandai dengan komentar `CATATAN BUG`.

## Requirement

- Python 3.10+ (disarankan)
- Library: `pygame` (satu-satunya dependency non-standard-library)

## Setup (Windows)

```bash
cd FlappyBird_Pygame
python -m venv venv
venv\Scripts\activate
pip install pygame
```

## Asset yang wajib ditambahkan sebelum menjalankan game

Taruh file-file berikut (belum disertakan dalam project ini) ke folder yang sesuai:

```
assets/images/
    Chara.png
    bg_start.png
    Loop_depan.png
    Loop_belakang.png
    Play_Button.png
    Restart_Button.png
    Obstacle_tiang_1.png
    Obstacle_tiang_2.png   (opsional, alternatif obstacle)
    Skor_Panel.png

assets/sounds/
    klik_bird.mp3
    Die.mp3
    Music_bg_awal.mp3
    Music_bg1.mp3
```

Jika asset tidak ditemukan saat game dijalankan, game **tidak akan crash** —
akan muncul warning di console (path yang dicari) dan game memakai fallback
sederhana (warna solid / teks) untuk elemen tersebut.

## Menjalankan

```bash
python main.py
```

## Status Stage

- [x] Stage 1 — Project setup
- [x] Stage 2 — Asset loading
- [x] Stage 3 — Menu
- [x] Stage 4 — Gameplay background
- [x] Stage 5 — Player
- [x] Stage 6 — Obstacle
- [x] Stage 7 — Score
- [x] Stage 8 — Collision / Game Over
- [x] Stage 9 — Audio
- [ ] Stage 10 — Animation (tween penuh; belum diimplementasikan — fallback
      easing sederhana sudah dipakai di Stage 5-8, lihat Known Limitations)

## Bug dari source asli — keputusan final

| Bug | Source behavior | Keputusan di port ini |
|---|---|---|
| Highscore key mismatch | Menu baca `localStorage['Highscore']`, gameOver simpan ke `localStorage["highscore"]` | **FIXED** — satu key konsisten `"highscore"`, dibaca/ditulis lewat `save.json` (lihat `game/menu.py`) |
| Timer typo (`timeHalangan` vs `timerHalangan`) | Property yang diinisialisasi beda dengan yang dipakai di update loop | **FIXED** — satu nama konsisten `obstacle_timer` di `game/play.py` |
| `this.trail` tidak pernah dibuat | Dipanggil `.setVisible(false)` saat mati, tapi tidak pernah diinisialisasi | **NOT PORTED** — dependency dihilangkan sepenuhnya, tidak ada fitur trail dibuat |
| `snd_transisi_menu` | Dipanggil `.play()`, tapi referensi tidak konsisten & asset tidak tersedia | **SAFELY SKIPPED** — ditandai `TODO: NEED USER CONFIRMATION` di `config.py` & `game/__init__.py` |
| `updateScore()` loop berhenti di `i > 0` (bukan `>= 0`) | Obstacle index 0 tidak pernah dicek untuk skor | **DIPERTAHANKAN** (bukan bug fix) — behavior gameplay asli tidak diubah, ditandai di `game/play.py` |
| `snd_klik_3` tidak pernah terpilih (`Math.random()*2` cuma hasilkan 0/1) | Salah satu dari 3 sound klik tidak pernah dipakai | **DIPERTAHANKAN** — formula random sama persis di `game/play.py` |

## Struktur Project

```
FlappyBird_Pygame/
├── main.py          # init pygame, window, clock, main loop, state switching
├── config.py         # konstanta: ukuran window, FPS, posisi, speed, asset map
├── game/
│   ├── __init__.py    # Assets: asset loading terpusat (Stage 2)
│   ├── menu.py         # state MENU + highscore save/load (Stage 3)
│   ├── play.py          # state PLAY: background, spawn, score, collision, audio
│   ├── player.py         # entity Player
│   └── obstacle.py        # entity Obstacle
├── assets/
│   ├── images/              # taruh file .png di sini
│   └── sounds/                # taruh file .mp3 di sini
├── save.json (dibuat otomatis saat game over pertama kali)
└── README.md
```

## Known Limitations

- **Stage 10 (tween/animasi penuh) belum lengkap.** Spawn player, flap, dan
  fade kematian sudah punya animasi sederhana (interpolasi linear/easing
  manual dengan `dt`), tapi belum sama persis dengan Phaser Tween Manager
  (`Elastic.easeOut`, dsb). Ini bukan bug — memang scope Stage 10 belum
  dikerjakan sesuai instruksi.
- `title_game` belum punya asset asli — memakai fallback teks "FLAPPY BIRD".
- `snd_transisi_menu` belum punya asset asli — di-skip dengan aman, tidak
  diganti sound lain.
- Obstacle memakai `Obstacle_tiang_1.png` sebagai mapping default untuk key
  `obste` (sesuai instruksi); `Obstacle_tiang_2.png` adalah alternatif yang
  bisa dipasang manual di `config.py` jika diperlukan.
- Musik gameplay (`Music_bg1.mp3` -> `snd_game_music`) adalah **penambahan
  yang disengaja (intentional improvement)** — source Phaser asli tidak
  memutar musik apa pun di scene Play. Jika ingin behavior 1:1 dengan
  source (tanpa musik gameplay), hapus baris pemanggilan `snd_game_music`
  di `PlayState.enter()` / `_trigger_player_death()`.
- Lingkungan pembuatan project ini tidak memiliki akses internet, sehingga
  `pygame` tidak dapat di-install & game tidak dapat dijalankan langsung di
  sini. Seluruh file sudah lolos `python -m py_compile` (tidak ada syntax
  error), tapi runtime testing perlu dilakukan di mesin Anda sendiri setelah
  `pip install pygame` dan asset ditaruh di folder yang benar.
