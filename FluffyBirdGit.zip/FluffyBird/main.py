"""
main.py - entry point, main loop, state switching (MENU <-> PLAY).

PYGAME EQUIVALENT dari struktur:
    pygame.init() -> create window -> create clock -> current_state = MENU
    -> while running: events -> update -> draw -> clock.tick(FPS)
"""

import pygame
import config
from game import Assets
from game.menu import MenuState
from game.play import PlayState


def main():
    pygame.init()
    try:
        pygame.mixer.init()
    except pygame.error as e:
        print(f"[main] WARNING: gagal inisialisasi mixer audio: {e}")

    screen = pygame.display.set_mode((config.GAME_WIDTH, config.GAME_HEIGHT))
    pygame.display.set_caption("Flappy Bird - Pygame Port")
    clock = pygame.time.Clock()

    assets = Assets()
    assets.load()

    states = {
        "menu": MenuState(assets),
        "play": PlayState(assets),
    }
    current_state_name = "menu"
    current_state = states[current_state_name]
    current_state.enter()

    running = True
    while running:
        dt = clock.tick(config.FPS) / 1000.0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            else:
                current_state.handle_event(event)

        current_state.update(dt)

        if current_state.next_state and current_state.next_state != current_state_name:
            current_state_name = current_state.next_state
            current_state = states[current_state_name]
            current_state.enter()

        current_state.draw(screen)
        pygame.display.flip()

    pygame.quit()


if __name__ == "__main__":
    main()
